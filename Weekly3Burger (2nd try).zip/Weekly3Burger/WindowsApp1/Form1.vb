﻿Public Class frmBurger

    Private Sub ButtonPrime_Click(sender As Object, e As EventArgs) Handles btnPrime.Click
        picPrime.Visible = True
        picVeggie.Visible = False
        btnSelectMeal.Enabled = True
    End Sub
    Private Sub ButtonVeggie_Click(sender As Object, e As EventArgs) Handles btnVeggie.Click
        picVeggie.Visible = True
        picPrime.Visible = False
        btnSelectMeal.Enabled = True
    End Sub
    Private Sub ButtonSelectMeal_Click(sender As Object, e As EventArgs) Handles btnSelectMeal.Click
        btnPrime.Enabled = False
        btnSelectMeal.Enabled = False
        btnVeggie.Enabled = False
        lblInstructions.Visible = False
        lblConfirmation.Visible = False
        btnExit.Enabled = True
    End Sub
    Private Sub ButtonExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub FrmBurger_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        picPrime.Visible = True
    End Sub

End Class
